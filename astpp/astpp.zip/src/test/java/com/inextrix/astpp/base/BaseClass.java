package com.inextrix.astpp.base;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	WebDriver driver;

	public BaseClass(WebDriver driver) {
		super();
		this.driver = driver;
	}

	
	
}
